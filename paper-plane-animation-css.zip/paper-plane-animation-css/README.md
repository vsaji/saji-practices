# Paper Plane Animation (CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/_ItsJonQ/pen/yvfDF](https://codepen.io/_ItsJonQ/pen/yvfDF).

A test animation loop of a paper plane flying through clouds.

This is 100% CSS, and the images are SVG.